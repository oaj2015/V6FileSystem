#ifndef INITFS
#define INITFS

#include "P2.h"

#include <string>
int initfs(std::string name, int n1, int n2);

#endif
